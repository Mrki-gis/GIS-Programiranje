from qgis.PyQt.QtCore import QVariant

# pravi se novi sloj
vl = QgsVectorLayer("Point?crs=epsg:32634", "Lokacije", "memory")
pr = vl.dataProvider()
pr.addAttributes([QgsField("Naziv", QVariant.String),
                  QgsField("Visina",  QVariant.Int),
                  QgsField("Opis", QVariant.String) ])
vl.updateFields()

# Dodavanje podataka
my_data = [
    {'x': 441222, 'y': 4798194, 'ime': 'Sjenica', 'visina': 25, 'opis': 'Kandidat'},
    {'x': 404927, 'y': 4792256, 'ime': 'Prijepolje', 'visina': 25, 'opis': 'Kandidat2'},
    {'x': 401531, 'y': 4807211, 'ime': 'Nova Varos', 'visina': 25, 'opis': 'Kandidat3'}]

for rec in my_data:
    f = QgsFeature()
    pt = QgsPointXY(rec['x'], rec['y'])
    f.setGeometry(QgsGeometry.fromPointXY(pt))
    f.setAttributes([rec['ime'], rec['visina'], rec['opis']])
    pr.addFeature(f)

vl.updateExtents()
QgsProject.instance().addMapLayer(vl)

'''# prvi izraz računa zbir visina vidikavaca
#drugi izraz kreira buffer zonu oko tačaka
expression2 = QgsExpression('sum("visina")')
expression3 = QgsExpression('area(buffer($geometry,"visina"))')

# QgsExpressionContextUtils.globalProjectLayerScopes() je funkcija koja nam pomaže
# da dodamo globalni obim (scope), projekat, i slojeve (unutar tog obima) u isto vreme
# Uvek se kreće od najopštijeg
# do najspecifičnijeg obima (npr. od gobalnog, ka projektu, ka slojevima)
context = QgsExpressionContext()
context.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(vl))

with edit(vl):
    for f in vl.getFeatures():
        context.setFeature(f)
        f['visina'] = expression2.evaluate(context)
        f['visina'] = expression3.evaluate(context)
        vl.updateFeature(f)

print(f['visina'])'''