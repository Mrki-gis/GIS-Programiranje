vlayer = iface.activeLayer()

renderer = vlayer.renderer()
print('Tip', renderer.type())
print(renderer.dump())

#menja simbol sloja
symbol = QgsFillSymbol.createSimple({'name': 'square', 'color': 'yellow'})
vlayer.renderer().setSymbol(symbol)
vlayer.triggerRepaint()

vlayer.renderer().symbol().symbolLayer(0).setSize(3)