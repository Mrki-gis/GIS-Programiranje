from qgis.core import (QgsCoordinateReferenceSystem,QgsCoordinateTransform,QgsProject,QgsPointXY,)

crsSrc = QgsCoordinateReferenceSystem('EPSG:6316')
# Univerzalni Transferzalni Merkator, zona 34N (odgovara prostoru Srbije)
crsDest = QgsCoordinateReferenceSystem('EPSG:32634')
transformContext = QgsProject.instance().transformContext()
xform = QgsCoordinateTransform(crsSrc, crsDest, transformContext)

tacka1 = xform.transform(QgsPointXY(7570802,4787373))
print('Transformisana tacka: ', tacka1)

'''
#inverzna transformacija
tacka2 = xform.transform(tacka1, QgsCoordinateTransform.ReverseTransform)
print('Ponovo transformisana: ', tacka2)
'''