'''from qgis.core import (edit,QgsExpression,QgsExpressionContext,QgsFeature,QgsFeatureRequest,QgsField,QgsFields,QgsVectorLayer,QgsPointXY,QgsGeometry,QgsProject,QgsExpressionContextUtils)'''

 #provera da li izraz može biti rastavjen
'''exp = QgsExpression('1 + 1 = 2')
assert(not exp.hasParserError())
exp = QgsExpression('1 + 1 = ')
assert(exp.hasParserError())

assert(exp.parserErrorString() == '\nsyntax error, unexpected $end')'''

#osnovni izrazi
exp = QgsExpression('3 * 3')
print(exp)
print(exp.evaluate())

#mogu se koristiti za poređenje gde je 1 = True ,a 0 = False
exp = QgsExpression('1 + 1 = 2')
exp.evaluate()
print(exp.evaluate())

fields = QgsFields()
field = QgsField('Kolona')
fields.append(field)
feature = QgsFeature()
feature.setFields(fields)
feature.setAttribute(0, 99)

exp = QgsExpression('"Kolona"')
context = QgsExpressionContext()
context.setFeature(feature)
exp.evaluate(context)
print(exp.evaluate(context))

'''vlayer = QgsProject.instance().mapLayersByName('Zlatiborski okrug')[0]
vlayer.startEditing()

izraz = 'Razlika >= 1000'
zahtev = QgsFeatureRequest().setFilterExpression(izraz)

matches = 0
for f in vlayer.getFeature(zahtev):
    matches += 1

print(matches)'''

vlayer = QgsVectorLayer("Polygon?field=Test:integer", "addfeature", "memory")

vlayer.startEditing()

for i in range(10):
    feature = QgsFeature()
    feature.setAttributes([i])
    assert(vlayer.addFeature(feature))
vlayer.commitChanges()

izraz = 'Test >= 3'
zahtev = QgsFeatureRequest().setFilterExpression(izraz)

matches = 0
for f in vlayer.getFeatures(zahtev):
   matches += 1
print(matches)
