import os
#putanja do .shp datoteke
#napomena:kada se prekopira putanja iz File Explorer-a izgleda ovako:C:\Users\Korisnik\Desktop\GF\I semestar\GIS analiza i modelovanje\5_Predavanje 30.11.2020\Podaci
#da bi kod radio, moraju se zameniti sve '\' sa '/'
#najbrži način meni trenutno poznat, selektovati '\',Ctrl+R i zameniti sa '/'

putanja_do_sloja = "C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/Zl_okrug.shp"

vlayer=QgsVectorLayer(putanja_do_sloja,'Zlatiborski okrug','ogr') #dali smo putanju, naziv koji će se prikazati u Qgis-u i provajdera(najčešće 'ogr')
if not vlayer.isValid():
    print('Sloj ne može da se učita')
else:
    QgsProject.instance().addMapLayer(vlayer)



