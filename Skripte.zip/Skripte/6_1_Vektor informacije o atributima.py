import os

#uzimajući u obzir da je vektorki sloj prethodno učitan u delu 3.1,
#da bi se videli podaci o atributima potrebno je pozvati sledeću opciju
for field in vlayer.fields():
    print(field.name(), field.typeName())

print(vlayer.displayField())
