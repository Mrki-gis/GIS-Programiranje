from qgis.PyQt import QtGui


#korišćeni sloj 'Zlatiborski okrug'
vlayer = iface.activeLayer()
atribut = 'Razlika'
opseg = []
prozirnost = 1
# kreira se prvi simbol i opseg
min = 800
max = 1150
naziv = '800-1150'
boja = QtGui.QColor('#f700ff')
prvi_simbol = QgsSymbol.defaultSymbol(vlayer.geometryType())
prvi_simbol.setColor(boja)
prvi_simbol.setOpacity(prozirnost)
prvi_opseg = QgsRendererRange(min, max, prvi_simbol, naziv)
opseg.append(prvi_opseg)
# drugi simbol
min = 1151
max = 2000
naziv = '1151-2000'
boja = QtGui.QColor('#fc0303')
drugi_simbol = QgsSymbol.defaultSymbol(vlayer.geometryType())
drugi_simbol.setColor(boja)
drugi_simbol.setOpacity(prozirnost)
drugi_opseg = QgsRendererRange(min, max, drugi_simbol, naziv)
opseg.append(drugi_opseg)

renderer = QgsGraduatedSymbolRenderer('', opseg)
metod_klasifikacije = QgsApplication.classificationMethodRegistry().method('EqualInterval')
renderer.setClassificationMethod(metod_klasifikacije)
renderer.setClassAttribute(atribut)

vlayer.setRenderer(renderer)
vlayer.triggerRepaint()











