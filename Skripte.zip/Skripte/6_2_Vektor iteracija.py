import os

#pretpostavka je da je vektorski sloj već učitan(deo 3.1)

vlayer = iface.activeLayer()
features = vlayer.getFeatures()

for feature in features:
    print("Feature ID: ", feature.id())
geom = feature.geometry()
geomSingleType = QgsWkbTypes.isSingleType(geom.wkbType())
if geom.type() == QgsWkbTypes.PointGeometry:

     if geomSingleType:
        x = geom.asPoint()
        print("Point: ", x)
     else:
        x = geom.asMultiPoint()
        print("MultiPoint: ", x)
elif geom.type() == QgsWkbTypes.LineGeometry:
     if geomSingleType:
        x = geom.asPolyline()
        print("Line: ", x, "length: ", geom.length())
     else:
         x = geom.asMultiPolyline()
         print("MultiLine: ", x, "length: ", geom.length())
elif geom.type() == QgsWkbTypes.PolygonGeometry:
     if geomSingleType:
        x = geom.asPolygon()
        print("Polygon: ", x, "Area: ", geom.area())
     else:
        x = geom.asMultiPolygon()
        print("MultiPolygon: ", x, "Area: ", geom.area())
else:
    print("Unknown or invalid geometry")

#attrs = feature.attributes()
#print(attrs)



