import os

vlayer = iface.activeLayer()
feat = QgsVectorLayerUtils.createFeature(vlayer)
#getValues omogućava brzo dobijanje vrednosti za određeni atribut ili izraz
vlayer.selectByIds([0])
value = QgsVectorLayerUtils.getValues(vlayer, 'Opstina', selectedOnly=True)
print(value)

