
vlayer = QgsProject.instance().mapLayersByName('Zlatiborski okrug')[0]
# može i preko iface.activeLayer()

# filtrira opštine čiji naziv počinje slovom  'P',
# zatim izvlači njihove feature-e
upit = '"Opstina" LIKE \'P%\''
features = vlayer.getFeatures(QgsFeatureRequest().setFilterExpression(upit))

# vrši iteraciju nad feature-ima, i izvršava
# geometrijsku komputaciju i štampa rezultate
for f in features:
    geom = f.geometry()
    naziv = f.attribute('Opstina')
    print(naziv)
    print('Površina (km_2): ', geom.area() / 1000000)
    print('Dužina (km): ', geom.length() / 1000)

# alternativni način
# štampa kod od elipsoida koji se koristi
# print(QgsProject.instance().ellipsoid())
# štampa sve elipsoide po njihovom kodu
# print(QgsEllipsoidUtils.acronyms())
'''d = QgsDistanceArea()
d.setEllipsoid('EPSG:32634')

for f in features:
    geom = f.geometry()
    naziv = f.attribute('Opstina')
    print(naziv)
    print('Dužina (km): ', d.measurePerimeter(geom)/1000)
    print('Površina (km_2): ', d.measureArea(geom)/1000000)'''
