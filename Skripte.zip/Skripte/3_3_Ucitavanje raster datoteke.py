import os
putanja_do_tif = 'C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/Zl_okrug_rec.tif'
#putanja uvek pod navodnike!!!
rlayer = QgsRasterLayer(putanja_do_tif,'Zlatiborski okrug rec')
if not rlayer.isValid():
    print('Raster ne može da se učita!')
else:
    QgsProject.instance().addMapLayer(rlayer)

