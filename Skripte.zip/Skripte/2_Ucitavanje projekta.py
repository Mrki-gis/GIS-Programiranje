# Skriptu je potrebno importovati ukoliko se pokreće izvan QGIS-a
# Klase koje ce se koristiti su qgis i PyQT
#ukoliko se pokreće izvan QGIS-a

'''from qgis.core import QgsProject'''

# Instanciranje projekta
project = QgsProject.instance()

# Učitavanje projekta
project.read('C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/UGP.qgz')

# Čuvanje projkta sa istim imenom
project.write()

# Čuvanje projekta sa različitim imenom
'''project.write('C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/UGP_novi_naziv.qgz')'''

# Menja loše "putanje", u slučaju da došlo do promene lokacije sloja, promene adrese od hosta baze podataka..
'''def my_processor(path):
    return path.replace('host=10.1.1.115', 'host=10.1.1.116')

QgsPathResolver.setPathPreprocessor(my_processor)'''