#ukoliko je standalone
'''
from qgis.PyQt.QtGui import (QColor,)
from qgis.PyQt.QtCore import Qt, QRectF
from qgis.core import (QgsVectorLayer, QgsPoint, QgsPointXY, QgsProject, QgsGeometry, QgsMapRendererJob,)
from qgis.gui import (QgsMapCanvas, QgsVertexMarker, QgsMapCanvasItem, QgsRubberBand,)
'''
canvas = QgsMapCanvas()
canvas.show()
#odmah otvara belu pozdainu...možda je do verzije
canvas.setCanvasColor(Qt.white)
canvas.enableAntiAliasing(True)

vlayer = iface.activeLayer()
if not vlayer.isValid():
    print('Sloj nije uspešno učitan!')
canvas.setExtent(vlayer.extent())
canvas.setLayers([vlayer])

linije = QgsRubberBand(canvas, False) # False označava da nije poligon
tacke = [
QgsPoint(403429,4806309),
QgsPoint(401834,4826715),
QgsPoint(391631,4849672)
]
linije.setToGeometry(QgsGeometry.fromPolyline(tacke), None)
linije.setWidth(3)
linije.setColor(QColor(255,255,255))

poligon = QgsRubberBand(canvas, True) # True označava da je u pitanju poligon
tacke = [
[QgsPointXY(423785,4761931),
QgsPointXY(442985,4795668),
QgsPointXY(423794,4809019),
QgsPointXY(398785,4832305) ]]

poligon.setToGeometry(QgsGeometry.fromPolygonXY(tacke), None)
poligon.setColor(QColor(255,0,0))
#kreirenje tačaka
m = QgsVertexMarker(canvas)
m.setCenter(QgsPointXY(401535,4807202))

m.setColor(QColor(50,50,200))
m.setIconSize(8)
m.setIconType(QgsVertexMarker.ICON_CIRCLE)
m.setPenWidth(4)

#sakrivanje i pokazivanje objekta
#polygon.hide()/polygon.show()
#uklanjanje sloja sa platna
#canavas.scene().removeItem(tacke)