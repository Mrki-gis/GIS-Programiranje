import os

#za selekciju celog sloja
'''
vlayer = iface.activeLayer()
vlayer.selectAll()
'''

#selekcija putem izraza(izvršena za priloženi vektorski sloj)

vlayer = iface.activeLayer()
vlayer.selectByExpression('"Razlika"> 1150 and "_max" >1590', QgsVectorLayer.SetSelection)

#za promenu boje selekcije
iface.mapCanvas().setSelectionColor( QColor("blue") )

#dodavanje već selektovanim oblicima
'''
selected_fid = []
for feature in vlayer.getFeatures():
    selected_fid.append(feature.id())
    break
vlayer.select(selected_fid)
'''
#za uklanjanje selekcije
'''
vlayer.removeSelection()
'''

#6.3.1
#pristupanje atributu na osnovu imena
'''
print(feature['Opstina'])
#pristupanje atributu na osnovu indeksa
print(feature[3])
'''
#6.3.2
#pristup samo selektovanim atributima
selekcija = vlayer.selectedFeatures()
for feature in selekcija:
    if feature['Razlika']>1150:
        print('Visinska razlika je veća od 1150m')
    else:
        print('Visinska razlika je manja od 1150m')