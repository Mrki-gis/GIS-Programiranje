import os
#from qgis.core import(QgsVectorLayer) - ukoliko je standalone

#putanja do gpkg
putanja = os.path.join(QgsApplication.pkgDataPath(), 'resources', 'data', 'C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/Putevi_ZL_okrug.gpkg')

gkplayer = QgsVectorLayer(putanja, 'Putevi Zlatiborski okrug', 'ogr')

if not gkplayer.isValid():
    print("Sloj nije uspešno učitan")
else:
    QgsProject.instance().addMapLayer(gkplayer)

