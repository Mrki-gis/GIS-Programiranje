import random
from time import sleep

from qgis.core import (
    QgsApplication, QgsTask, QgsMessageLog,
    )
#standalone
MESSAGE_CATEGORY = 'RandomIntegerSumTask'

class RandomIntegerSumTask(QgsTask):
    """Pokazuje kako napraviti podklasu QgsTask klase"""

    def __init__(self, description, duration):
        super().__init__(description, QgsTask.CanCancel)
        self.duration = duration
        self.total = 0
        self.iterations = 0
        self.exception = None

    def run(self):
        """
        Mora vratiti True ili False.

        """
        QgsMessageLog.logMessage('Task započet "{}"'.format(
                                     self.description()),
                                 MESSAGE_CATEGORY, Qgis.Info)
        wait_time = self.duration / 100
        for i in range(100):
            sleep(wait_time)
            # koristi se  setProgress da izvesti o napretku
            self.setProgress(i)
            arandominteger = random.randint(0, 500)
            self.total += arandominteger
            self.iterations += 1
            #provera task.isCanceled() kako bi postupio sa prekidanjem
            if self.isCanceled():
                return False
            # simulira izuzetak kako bi se prikazalo kako se prekida task
            if arandominteger == 14:
                # DO NOT raise Exception('bad value!')
                # doći će do obaranja QGIS -
                self.exception = Exception('Loša vrednost')
                return False
        return True

    def finished(self, result):
        """
        Automatski se pokreće kada se task završi bez obzira da li se uspešno ili
        neuspešno završio
        Definiše se šta ide nakaon završetka taska

        """
        if result:
            QgsMessageLog.logMessage(
                'RandomTask "{name}" completed\n' \
                'RandomTotal: {total} (with {iterations} ' \
                'iterations)'.format(
                    name=self.description(),
                    total=self.total,
                    iterations=self.iterations),
                MESSAGE_CATEGORY, Qgis.Success)
        else:
            if self.exception is None:
                QgsMessageLog.logMessage(
                    'RandomTask "{name}" not successful but without '\
                    'exception (probably the task was manually '\
                    'canceled by the user)'.format(
                        name=self.description()),
                    MESSAGE_CATEGORY, Qgis.Warning)
            else:
                QgsMessageLog.logMessage(
                    'RandomTask "{name}" Exception: {exception}'.format(
                        name=self.description(),
                        exception=self.exception),
                    MESSAGE_CATEGORY, Qgis.Critical)
                raise self.exception

    def cancel(self):
        QgsMessageLog.logMessage(
            'RandomTask "{name}" was canceled'.format(
                name=self.description()),
            MESSAGE_CATEGORY, Qgis.Info)
        super().cancel()


longtask = RandomIntegerSumTask('waste cpu long', 20)
shorttask = RandomIntegerSumTask('waste cpu short', 10)
minitask = RandomIntegerSumTask('waste cpu mini', 5)
shortsubtask = RandomIntegerSumTask('waste cpu subtask short', 5)
longsubtask = RandomIntegerSumTask('waste cpu subtask long', 10)
shortestsubtask = RandomIntegerSumTask('waste cpu subtask shortest', 4)

# dodaje podtask kratkom tasku, koji mora biti pokrenut

shorttask.addSubTask(shortsubtask, [minitask, longtask])
# dodaje podtask dugačkom tasku, koji mora biti pokrenut pre 'roditeljskog' taska
longtask.addSubTask(longsubtask, [], QgsTask.ParentDependsOnSubTask)
#dadaje podtask dugačkom task - u
longtask.addSubTask(shortestsubtask)

QgsApplication.taskManager().addTask(longtask)
QgsApplication.taskManager().addTask(shorttask)
QgsApplication.taskManager().addTask(minitask)

