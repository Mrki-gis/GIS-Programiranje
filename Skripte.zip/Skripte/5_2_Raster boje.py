import os


rlayer = QgsProject.instance().mapLayersByName('Zlatiborski okrug 20 km')[0]

#kako se beše ovo zove kod nas!?!
#print(rlayer.renderer())
#print(rlayer.renderer().type())

fcn = QgsColorRampShader()
fcn.setColorRampType(QgsColorRampShader().Interpolated)
lst = [QgsColorRampShader.ColorRampItem(0, QColor(0, 255, 0)),
       QgsColorRampShader.ColorRampItem(255, QColor(255, 255, 0))]
fcn.setColorRampItemList(lst)
shader = QgsRasterShader()
shader.setRasterShaderFunction(fcn)

renderer = QgsSingleBandPseudoColorRenderer(rlayer.dataProvider(), 1, shader)
rlayer.setRenderer(renderer)

#da bi se rezultati prikazali

rlayer.triggerRepaint()

