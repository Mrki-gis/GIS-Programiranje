import os

#kreira se sloj
sLoj = QgsVectorLayer('Point?crs=epsg:32634', 'prr_tacke', 'memory')
pr = sLoj.dataProvider()

#dodavanje atributa
pr.addAttributes([QgsField("ime", QVariant.String),QgsField("godine",  QVariant.Int),QgsField("velicina", QVariant.Double)])

#upoznajemo vektorski sloj da ažurira promene od provajdera
sLoj.updateFields()
#dodavanje feature

feat = QgsFeature()
feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(393206,4843202)))
feat.setAttributes(['CBD', 2, 0.3])
pr.addFeatures([feat])

#ažurira obim sloja kada su dodati novi features pošto se promena obima provajdera ne odražava direktno na sloj
sLoj.updateExtents
#prikaz nekih karakteristika

print('fields: ', len(pr.fields()))
print('features: ', pr.featureCount())
e = sLoj.extent()
print('obim: ', e.xMinimum(), e.yMinimum(), e.xMaximum(), e.yMaximum())

#iteracija nad feature
features = sLoj.getFeatures()
for feat in features:
    print('F: ', feat.id(), feat.attributes(), feat.geometry().asPoint())

