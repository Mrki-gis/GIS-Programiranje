import os

#definisanje atributa
atributi = QgsFields()
atributi.append(QgsField('Jedan', QVariant.Int))
atributi.append(QgsField('Dva', QVariant.String))


crs = QgsProject.instance().crs()
transform_context = QgsProject.instance().transformContext()
save_options = QgsVectorFileWriter.SaveVectorOptions()
save_options.driverName = "ESRI Shapefile"
save_options.fileEncoding = "UTF-8"

writer = QgsVectorFileWriter.create('C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/Proba3',atributi,QgsWkbTypes.Point,crs,transform_context,save_options)

if writer.hasError() != QgsVectorFileWriter.NoError:
    print('Došlo je do greške ', writer.errorMessage())

#dodavanje feature
fet = QgsFeature()

fet.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(7402068,4815526)))
fet.setAttributes([1, "ime"])
writer.addFeature(fet)

del writer


