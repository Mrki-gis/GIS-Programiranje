vlayer=iface.activeLayer()
#Za potrebe ovog primera u sloju Zlatiborski okrug kreirano je polje kat_primer

kategorizovani_renderer = QgsCategorizedSymbolRenderer()
kat1 = QgsRendererCategory('0', QgsFillSymbol(), 'kat 1')
kat2 = QgsRendererCategory('1', QgsFillSymbol(), 'kat 2')

#kreiranje simbola za svaku kategoriju

s1= QgsFillSymbol.createSimple({'name': '', 'color': 'blue'})
kat1.setSymbol(s1)
s2= QgsFillSymbol.createSimple({'name': '', 'color': 'yellow'})
kat1.setSymbol(s2)

#dodavanje kategorija
kategorizovani_renderer.addCategory(kat1)
kategorizovani_renderer.addCategory(kat2)

for kat in kategorizovani_renderer.categories():
    print('{}: {} :: {}'.format(kat.value(), kat.label(), kat.symbol()))

kategorizovani_renderer.setClassAttribute('kat_primer')
vlayer.setRenderer(kategorizovani_renderer)
vlayer.triggerRepaint()
#kako bi naredni zadaci isprobani može se učitati ponovo .shp Zlatiborski okrug
'''putanja_do_sloja = "C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/Zl_okrug.shp"

vlayer=QgsVectorLayer(putanja_do_sloja,'Zlatiborski okrug','ogr') #dali smo putanju, naziv koji će se prikazati u Qgis-u i provajdera(najčešće 'ogr')
if not vlayer.isValid():
    print('Sloj ne može da se učita')
else:
    QgsProject.instance().addMapLayer(vlayer)'''


