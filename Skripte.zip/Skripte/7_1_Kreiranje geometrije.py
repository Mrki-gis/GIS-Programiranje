'''from qgis.core import ( QgsGeometry,QgsPoint,QgsPointXY,QgsWkbTypes,QgsProject,QgsFeatureRequest,QgsVectorLayer,QgsDistanceArea,QgsUnitTypes,QgsCoordinateTransform,QgsCoordinateReferenceSystem)'''

#kreiranje geometrije iz koordinata
Tacka = QgsGeometry.fromPointXY(QgsPointXY(409051,4860183))
print(Tacka)
Linija = QgsGeometry.fromPolyline([QgsPoint(401531,4807211), QgsPoint(441222,4798194)])
print(Linija)
Poligon = QgsGeometry.fromPolygonXY([
[QgsPointXY(401531,4807211),
QgsPointXY(441222,4798194),
QgsPointXY(404972,4792256)]
])
print(Poligon)



''''#WKT-well known text format
geom_iz_wkt = QgsGeometry.fromWkt('POINT(420628,4820427)')
print(geom_iz_wkt)'''

# WKB - well-known binary format
geom = QgsGeometry()
wkb = bytes.fromhex("010100000000000000000045400000000000001440")
geom.fromWkb(wkb)
print(geom.asWkt())
