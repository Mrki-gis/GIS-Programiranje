import time

'''from qgis.PyQt.QtWidgets import QProgressBar
from qgis.PyQt.QtCore import *'''

napredakPoruka = iface.messageBar().createMessage('Uploading...')
napredak = QProgressBar()
napredak.setMaximum(5)
napredak.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
napredakPoruka.layout().addWidget(napredak)
iface.messageBar().pushWidget(napredakPoruka, Qgis.Info)

for i in range(7):
    time.sleep(1)
    napredak.setValue(i + 1)

# iface.messageBar().clearWidgets()


vlayer = QgsProject.instance().mapLayersByName('Zlatiborski okrug')[0]

count = vlayer.featureCount()
features = vlayer.getFeatures()

for i, feature in enumerate(features):
    print(i)
    procenat = i / float(count) * 100

    iface.mainWindow().statusBar().showMessage('Obrađeno {}%'.format(int(procenat)))
    iface.statusBarIface().showMessage('Obrađeno {}%'.format(int(procenat)))

# ukoliko želimo da obrišemo poruku
# iface.statusBarIface().clearMessage()