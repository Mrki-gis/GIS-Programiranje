import os

#raster je već učitan u delu 3
rlayer = QgsProject.instance().mapLayersByName('Zlatiborski okrug 20 km')[0]

#rezolucija rastera
print(rlayer.width(), rlayer.height())

#prostiranje rastera
print(rlayer.extent())

#prostiranje rastera ali kao string
print(rlayer.extent().toString())

#tip rastera
print(rlayer.rasterType())

#broj kanala
print(rlayer.bandCount())

#naziv prvog kanala
print(rlayer.bandName(1))

#svi metapodaci
print(rlayer.metadata())
