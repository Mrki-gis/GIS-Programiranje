'''from qgis.core import (QgsProject,QgsSettings,QgsVectorLayer)'''
#standalone

#čuva podešavanja na globalnom nivou
def store():
  s = QgsSettings()
  s.setValue("myplugin/mojtekst", "UGP")
  s.setValue("myplugin/mojcelobrojni",  10)
  s.setValue("myplugin/mojrealni", 3.14)

def read():
  s = QgsSettings()
  mytext = s.value("myplugin/mojtekst", "UGP")
  myint  = s.value("myplugin/mojcelobrojni", 10)
  myreal = s.value("myplugin/mojrealni",3.14)

  print(mytext)
  print(myint)
  print(myreal)

store()

read()

project = QgsProject.instance()

# čuva vrednosti
project.writeEntry("myplugin", "mojtekst", "Upravljanje Projektima")
project.writeEntry("myplugin", "mojcelobrojni", 8)
project.writeEntryDouble("myplugin", "mojrealni", 2.04)
project.writeEntryBool("myplugin", "bulovaalgebra", True)

# čita vrednosti (vraća torku sa vrednostima, i Bulov status
# koji govori da li se vraćena vrednost može konvertovati u njen tip,
# odnosno iz stringa, celobrojnog broja, realnog broja i Bulovog izraza
mytext, type_conversion_ok = project.readEntry("myplugin","mojtekst","UGP")
myint, type_conversion_ok = project.readNumEntry("myplugin","mojcelobrojni",123)
mydouble, type_conversion_ok = project.readDoubleEntry("myplugin","mojrealni",123)
mybool, type_conversion_ok = project.readBoolEntry("myplugin","mybool",123)

vlayer = QgsProject.instance().mapLayersByName("Zlatiborski okrug")[0]
# cuva vrednost za odredjeni lejer
vlayer.setCustomProperty('mojtekst', 'Opštine Zlatiborskog okruga')
# ponovo cita vrednost; drugi argument vraca
tekst = vlayer.customProperty('mojtekst', 'nemateksta')
print(tekst)

