'''from qgis.gui import *
from qgis.PyQt.QtWidgets import QAction, QMainWindow
from qgis.PyQt.QtCore import Qt '''
#standalone

vlayer = QgsProject.instance().mapLayersByName('Zlatiborski okrug')[0]

class MyWnd(QMainWindow):
    def __init__(self, vlayer):
        QMainWindow.__init__(self)

        self.canvas = QgsMapCanvas()
        self.canvas.setCanvasColor(Qt.blue)

        self.canvas.setExtent(vlayer.extent())
        self.canvas.setLayers([vlayer])

        self.setCentralWidget(self.canvas)

        self.actionZoomIn = QAction("Uveličavanje", self)
        self.actionZoomOut = QAction("Odaljivanje", self)
        self.actionPan = QAction("Pomeranje", self)

        self.actionZoomIn.setCheckable(True)
        self.actionZoomOut.setCheckable(True)
        self.actionPan.setCheckable(True)

        self.actionZoomIn.triggered.connect(self.zoomIn)
        self.actionZoomOut.triggered.connect(self.zoomOut)
        self.actionPan.triggered.connect(self.pan)

        self.toolbar = self.addToolBar("Canvas actions")
        self.toolbar.addAction(self.actionZoomIn)
        self.toolbar.addAction(self.actionZoomOut)
        self.toolbar.addAction(self.actionPan)

        # kreiranje alata za mapu
        self.toolPan = QgsMapToolPan(self.canvas)
        self.toolPan.setAction(self.actionPan)
        self.toolZoomIn = QgsMapToolZoom(self.canvas, False) # false = in
        self.toolZoomIn.setAction(self.actionZoomIn)
        self.toolZoomOut = QgsMapToolZoom(self.canvas, True) # true = out
        self.toolZoomOut.setAction(self.actionZoomOut)

        self.pan()

    def zoomIn(self):
        self.canvas.setMapTool(self.toolZoomIn)

    def zoomOut(self):
        self.canvas.setMapTool(self.toolZoomOut)

    def pan(self):
        self.canvas.setMapTool(self.toolPan)
prozor = MyWnd(vlayer)
prozor.show()

def callback(feature):
# Kod koji se poziva kada je feature izabran od strane korisnika
    print('Pritisnuli ste na entitet {}'.format(feature.id()))

canvas = iface.mapCanvas()
feature_identifier = QgsMapToolIdentifyFeature(canvas)

# ukazuje na kom sloju će biti izvršena selekcija
feature_identifier.setLayer(vlayer)

# koristi callback funkciju kao slot koji se aktivira kada korisnik identifikuje feature
feature_identifier.featureIdentified.connect(callback)

# aktivacija alata
canvas.setMapTool(feature_identifier)

