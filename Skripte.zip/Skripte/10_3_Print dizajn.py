import os

project = QgsProject.instance()
layout = QgsPrintLayout(project)
layout.initializeDefaults()

layout.setName("NoviLayout")
project.layoutManager().addLayout(layout)

#glavni predmeti koji mogu da se dodaju u 'layout'
#karta
map = QgsLayoutItemMap(layout)
#podešavanje pozicije i veličine karte
map.attemptMove(QgsLayoutPoint(5,5, QgsUnitTypes.LayoutMillimeters))
map.attemptResize(QgsLayoutSize(200,200, QgsUnitTypes.LayoutMillimeters))
#definisanje obima koji će se renderovati
map.zoomToExtent(iface.mapCanvas().extent())
layout.addLayoutItem(map)

#kreiranje natpisa
label = QgsLayoutItemLabel(layout)
label.setText("Karta Zlatiborskog okruga")
label.adjustSizeToText()
layout.addLayoutItem(label)

#kreiranje legende
legend = QgsLayoutItemLegend(layout)
legend.setLinkedMap(map)
layout.addLayoutItem(legend)

#kreiranje razmernika
item = QgsLayoutItemScaleBar(layout)
item.setStyle('Numeric')
item.setLinkedMap(map)
item.applyDefaultSize()
layout.addLayoutItem(item)

#kreiranje strelice za sever
arrow = QgsLayoutItemPicture(layout)
arrow.setPicturePath('C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/pokazivac_severa')
layout.addLayoutItem(arrow)

#kreiranim predmetima može se menjeati veličina i pozicija
'''item.attemptMove(QgsLayoutPoint(1.4, 1.8, QgsUnitTypes.LayoutCentimeters))
item.attemptResize(QgsLayoutSize(2.8, 2.2, QgsUnitTypes.LayoutCentimeters))'''

#čuvanje karte

'''base_path = os.path.join(QgsProject.instance().homePath())
pdf_path = os.path.join(base_path, "izlaz.pdf")

exporter = QgsLayoutExporter(layout)
exporter.exportToPdf(pdf_path, QgsLayoutExporter.PdfExportSettings())'''

#!!!skripta nije funkcionalna, ne mogu da utvrdim tačan problem, za početak i ne otvara layout!!!