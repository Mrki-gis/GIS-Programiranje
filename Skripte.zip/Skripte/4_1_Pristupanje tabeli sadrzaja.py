import os
#ista stvar urađena na kraju prošlog dela
'''layers = QgsProject.instance().mapLayers()
print(layers)'''

l = [layer.name() for layer in QgsProject.instance().mapLayers().values()]
lista_slojeva = {}
for l in QgsProject.instance().mapLayers().values():
    lista_slojeva[l.name()]  = l
    print(lista_slojeva)

#upit se može postavit i za konkretan sloj, koristeći naziv sloja
#kako u QGIS dva sloja mogu imati identičan naziv, 0 označava da će program vratiti prvi sloj toga imena na koji naiđe
konkretan_sloj = QgsProject.instance().mapLayersByName('VP_Nova_Varos')[0]
print(konkretan_sloj)
