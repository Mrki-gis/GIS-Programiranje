from qgis.core import (QgsCoordinateReferenceSystem,QgsCoordinateTransform,QgsProject,QgsPointXY,) #ukoliko je standalone skripta
#određivanje CRS preko ID-a

crs = QgsCoordinateReferenceSystem('EPSG:6316')
print(crs.isValid())

#određivanje CRS preko well-known text(wkt)
'''
wkt = 'GEOGCS["WGS84", DATUM["WGS84", SPHEROID["WGS84", 6378137.0, 298.257223563]],' \
      'PRIMEM["Greenwich", 0.0], UNIT["degree",0.017453292519943295],' \
      'AXIS["Longitude",EAST], AXIS["Latitude",NORTH]]'
crs2 = QgsCoordinateReferenceSystem(wkt)
print(crs2.isValid())
'''
#komande za pristup informacijama o koordinatnom sistemu
print("QGIS CRS ID:", crs.srsid())
print("PostGIS SRID:", crs.postgisSrid())
print("Opis:", crs.description())
print("Akronim projekcije:", crs.projectionAcronym())
print("Akronim elipsoida:", crs.ellipsoidAcronym())
print("Proj String:", crs.toProj())
print("Da li je geografski :", crs.isGeographic())
print("Merna jedinica:", crs.mapUnits())

'''
print("QGIS CRS ID:", crs2.srsid())
print("PostGIS SRID:", crs2.postgisSrid())
print("Opis:", crs2.description())
print("Akronim projekcije:", crs2.projectionAcronym())
print("Akronim elipsoida:", crs2.ellipsoidAcronym())
print("Proj String:", crs2.toProj())
print("Da li je geografski :", crs2.isGeographic())
print("Merna jedinica:", crs2.mapUnits())
'''
