import os
putanja_slika =os.path.join(QgsProject.instance().homePath(), "C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/Primer_slika.png")

vlayer = iface.activeLayer()
settings = QgsMapSettings()
settings.setLayers([vlayer])
settings.setBackgroundColor(QColor(255, 255, 255))
settings.setOutputSize(QSize(800, 600))
settings.setExtent(vlayer.extent())

render = QgsMapRendererParallelJob(settings)

def finished():
    slika = render.renderedImage()
    #čuvanje slike
    slika.save(putanja_slika, "png")

render.finished.connect(finished)


render.start()

#nije potrebno ukoliko se skripta pokreće unutar QGIS-a
'''from qgis.PyQt.QtCore import QEventLoop
loop = QEventLoop()
render.finished.connect(loop.quit)
loop.exec_()'''