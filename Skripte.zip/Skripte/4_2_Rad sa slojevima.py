import os

root = QgsProject.instance().layerTreeRoot()
root.children()
child0 = root.children()[0]
print(child0)

#pristup preko jedinstvenog ID-a
ids = root.findLayerIds()
root.findLayer(ids[0])
'''print(ids[0])'''
#ukoliko ovde idemo print(ids[0]) u konzoli nam izbacuje prvi sloj sa njegovim id

#pretraživanje grupa
'''grupa=root.findGroup('Vidikovac_kandidati')
print(grupa)'''

#izbacuje listu štikliranih slojeva
checked_layers = root.checkedLayers()
print(checked_layers)
