import os

#dodavanje slojeva
sloj1 = QgsVectorLayer('C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/pokazni_sloj','Primer','memory')

#dodavanje sloja na poslednje mesto u tabeli sadržaja
'''root.addLayer(sloj1)'''

#dodavanje sloja na željenu poziciju
root.insertLayer(3, sloj1)

# Takodje moguće je dodati sloj u registar slojeva mape
# QgsProject.instance()addMapLayer(sloj1)

#dodavanje grupa
grupa2 = root.addGroup('Primer grupe')
podgrupa=grupa2.addGroup('Primer podgrupe')

#prebacivanje - odvija se u tri koraka
#1.kloniranje postojeće grupe
#2.njeno prebacivanje na željeno mesto
#3.brisanje originala
'''
cloned_group1 = grupa2.clone()
root.insertChildNode(2, cloned_group1) #broj označava poziciju u tabeli sadržaja
root.removeChildNode(grupa2)
'''
