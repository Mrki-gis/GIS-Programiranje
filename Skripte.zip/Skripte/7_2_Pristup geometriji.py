'''from qgis.core import ( QgsGeometry,QgsPoint,QgsPointXY,QgsWkbTypes,QgsProject,QgsFeatureRequest,QgsVectorLayer,QgsDistanceArea,QgsUnitTypes,QgsCoordinateTransform,QgsCoordinateReferenceSystem)'''

#kreiranje geometrije iz koordinata
Tacka = QgsGeometry.fromPointXY(QgsPointXY(409051,4860183))
#print(Tacka)
Linija = QgsGeometry.fromPolyline([QgsPoint(401531,4807211), QgsPoint(441222,4798194)])
#print(Linija)
Poligon = QgsGeometry.fromPolygonXY([
[QgsPointXY(401531,4807211),
QgsPointXY(441222,4798194),
QgsPointXY(404972,4792256)]
])
#print(Poligon)

#provera tipa geometrije
if Tacka.wkbType() == QgsWkbTypes.Point:
    print(Tacka.wkbType())
#Izlaz: 1 za tačku
if Linija.wkbType() == QgsWkbTypes.LineString:
    print(Linija.wkbType())
#Izlaz: 2 za liniju
if Poligon.wkbType() == QgsWkbTypes.Polygon:
    print(Poligon.wkbType())
#Izlaz: 3 za poligon

#drugi način

print(QgsWkbTypes.displayString(Tacka.wkbType()))
# izlaz: Point
print(QgsWkbTypes.displayString(Linija.wkbType()))
# izlaz: LineString
print(QgsWkbTypes.displayString(Poligon.wkbType()))
# izlaz: Polygon

# proverava da li je geometrija sastavljena iz vise delova ili ne
print(Tacka.isMultipart())
#vraća True ili False

print('--------------')

# metode za pristup svakom vektorskom tipu torke predstavljanje
# u vidu XY koordinata nisu prave torke već QgsPoint objekti, čijim
# vrednostima se može pristupiti pomoću x() i y() metodama
print(Tacka.asPoint())
print(Linija.asPolyline())
print(Poligon.asPolygon())
# za multipart geometrije to su: asMultiPoint(), asMultiPolyline(), asMultiPolygon()


# vrši iteraciju nad svim delovima geometrije
for deo in Poligon.parts():
    print(deo.asWkt())

# vrši transformaciju svakog dela geometrije
for deo in Tacka.parts():
    deo.transform(QgsCoordinateTransform(
    QgsCoordinateReferenceSystem('EPSG:6316'),
    QgsCoordinateReferenceSystem('EPSG:32634'),
    QgsProject.instance())
    )
print(Tacka.asWkt())