import os
sloj1 = QgsVectorLayer('point?crs=epsg:6316&field=id:integer', 'Proba','memory')
save_options = QgsVectorFileWriter.SaveVectorOptions()
transform_context = QgsProject.instance().transformContext()

#za čuvanje u GeoPackage formatu
error = QgsVectorFileWriter.writeAsVectorFormatV2(sloj1, "C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/proba_gpkg", transform_context, save_options)
if error[0] == QgsVectorFileWriter.NoError:
    print("Uspešno kreiranje sloja!")
else:
  print(error)


#za čuvanje u .shp formatu
sloj2 = QgsVectorLayer('polygon?crs=epsg:6316&field=id:integer', 'polygon', 'memory')
save_options = QgsVectorFileWriter.SaveVectorOptions()
save_options.driverName = "ESRI Shapefile"
save_options.fileEncoding = "UTF-8"
transform_context = QgsProject.instance().transformContext()
error = QgsVectorFileWriter.writeAsVectorFormatV2(sloj2, "C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/Proba2", transform_context, save_options)
if error[0] == QgsVectorFileWriter.NoError:
    print("Uspešno kreiranje sloj(.shp)!")
else:
  print(error)


  
