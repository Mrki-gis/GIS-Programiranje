vlayer= iface.activeLayer()

# vrši iteraciju nad podskupom feature-a
# unutar određenog prostora
podrucjeInteresa = QgsRectangle(345547, 4892771, 452022, 4731179)
request = QgsFeatureRequest().setFilterRect(podrucjeInteresa)

for feature in vlayer.getFeatures(request):
    if feature[6] < 50.0:
        print('Površina poligona je manja od 50km kvadratnih')
    else:
        print('Površina poligona je veca od 50km kvadratnih')

# moguće je postaviti limit koliko feature-a
# želimo da bude vraceno
request.setLimit(2)
for feature in vlayer.getFeatures(request):
    print(feature)

# ukoliko želimo da izvršimo iteraciju i filtriranje na osnovu
# određenog atributa, tu možemo iskoristimo QgsExpression objekat
# i da ga prosledimo QgsFeatureRequest konstruktoru
izraz = QgsExpression('eroz > 0.5')
request = QgsFeatureRequest(izraz)

for feature in vlayer.getFeatures(request):
    print(feature[1])

# još neke korisne metode, namerno stavljene kao varijable
# vraća samo izabrane atribute, kako bi se ubrzao zahtev
x = request.setSubsetOfAttributes([1, 6])

#drugi način
y = request.setSubsetOfAttributes(['_min', 'Razlika'], vlayer.fields())
# ne vraća objekte geometrije, kako bi se dodatno ubrzao zahtev
z = request.setFlags(QgsFeatureRequest.NoGeometry)

# vraća samo feature sa specifično navedenim ID
c = request.setFilterFid(9)

# moguće je određene opcije povezati i iskoristiti istovremeno
request.setFilterRect(podrucjeInteresa).setFlags(QgsFeatureRequest.NoGeometry).setFilterFid(1). \
    setSubsetOfAttributes([1, 6])

for feature in vlayer.getFeatures(request):
    print(feature[1])
    print(str(feature[6]))