import os
#kreiranje indeksa
index = QgsSpatialIndex()

vlayer = iface.activeLayer()
feat  = QgsFeature(vlayer.fields())

index = QgsSpatialIndex(vlayer.getFeatures())
#vraća ID najbližih features - a
najblizi = index.nearestNeighbor(QgsPointXY(7567041,4786615), 5)
print(najblizi)



