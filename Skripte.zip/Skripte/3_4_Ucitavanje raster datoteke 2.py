import os

putanja_do_tif = 'C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/Zl_okrug_20km.tif'
rlayer = QgsRasterLayer(putanja_do_tif,'Zlatiborski okrug 20 km')
if not rlayer.isValid():
    print('Raster ne može da se učita!')
QgsProject.instance().addMapLayer(rlayer, False)
layerTree = iface.layerTreeCanvasBridge().rootGroup()
layerTree.insertChildNode(-1, QgsLayerTreeLayer(rlayer))
#-1 znači da će ostali slojevi biti iznad sloja koji učitavam
maps = QgsProject.instance().mapLayers()
print(maps)
#QgsProject.instance().removeMapLayer(ovde dajem id sloja koji želim da se obriše,
# a koji zapravo vidim u konzoli uz pomoć mapLayers())

