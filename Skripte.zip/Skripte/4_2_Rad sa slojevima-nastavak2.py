root = QgsProject.instance().layerTreeRoot()
vlayer = QgsProject.instance().mapLayersByName('Zlatiborski okrug')[0]


# pomeranje slojeva u legendi
# kreiranje objekta QgsLayerTreeLayer iz Gradovi po njegovom ID-u
myvlayer = root.findLayer(vlayer.id())
# klonira se prethodno kreirani objekat
myvlayerclone = myvlayer.clone()
# uzima "roditelja". Ukoliko je rezultat None,
# znači da sloj nije ni u jednog grupi i vratiće ''
roditelj = myvlayer.parent()
# pomera se klonirani sloj na željenu poziciju, ovaj sloj na vrh ide u ovom slučaju
roditelj.insertChildNode(0, myvlayerclone)
# uklanja se originalni sloj
root.removeChildNode(myvlayer)

# prebacivanje sloja u određenu grupu (sličan postupak kao kod pomeranja)
xlayer = QgsProject.instance().mapLayersByName('Recc')[0]
myxlayer = root.findLayer(xlayer.id())
myxlayerclone = myxlayer.clone()
# kreiranje nove grupe
grupa1 = root.addGroup('Pomoćni raster')
roditelj = myxlayer.parent()
grupa1.insertChildNode(0, myxlayerclone)
roditelj.removeChildNode(myxlayer)



# još neke metode, koje mogu da se koriste za menjanje
# grupa i slojeva

# menjanje imena grupe
# grupa1.setName('Pomoćni raster reklasifikovan')



# uključivanje i isključivanje slojeva
#node_group1.setItemVisibilityChecked(True)
#node_layer2.setItemVisibilityChecked(False)

# proširuje i sakriva grupe u legendi
#Vidno_polje.setExpanded(True)
#Vidno_polje.SetExpanded(False)