# from qgis.PyQt.QtCore import QVariant (ukoliko smo izvan qgis-a)
putanja_do_sloja2 = "C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/Nova_Varos_kandidat.shp"



olayer = iface.activeLayer()

caps = olayer.dataProvider().capabilities()

# dodaje atribute izabranom lejeru
if caps and QgsVectorDataProvider.AddAttributes:
    res = olayer.dataProvider().addAttributes(
        [QgsField('Opis', QVariant.String), QgsField('Povrs_km2', QVariant.Int)])


# briše atribut na osnovu njegovog indeksa
# ukloniti '#' da bi se izvršilo brisanje
# if caps and QgsVectorDataProvider.DeleteAttributes:
# res = olayer.dataProvider().deleteAttributes([6])

# alternativne metode za brisanje atributa
olayer.dataProvider().addAttributes([QgsField('AB', QVariant.Int), \
                                    QgsField('AC', QVariant.Int), QgsField('AS', QVariant.Int)])
olayer.updateFields()  # ažurira dodate/obrisane atribute
# štampa atribute koji su trenutno dodeljeni sloju
for atribut in olayer.fields():
    print(atribut.name())
print('--------------------------')
count = olayer.fields().count()  # vraća broj atributa u sloju
lista_indeksa = list((count - 3, count - 2))

# briše jedan atribut pomoću indeksa
olayer.dataProvider().deleteAttributes([count - 1])

# briše više atributa pomoću liste sa indeksima
olayer.dataProvider().deleteAttributes(lista_indeksa)
olayer.updateFields()

for atribut in olayer.fields():
    print(atribut.name())