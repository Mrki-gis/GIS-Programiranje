import os

#proveravanje da li je određena funkcija moguća
caps = vlayer.dataProvider().capabilities()
if caps & QgsVectorDataProvider.DeleteFeatures:
    print('Sloj podržava brisanje atributa.')

#proveravanje svih funkcija koje sloj dozvoljava

caps_strings = vlayer.dataProvider().capabilitiesString()
print(caps_strings)

sloj = iface.activeLayer()
print(sloj.isEditable())
#ukoliko se radi iz QGIS-a, moguće da obično osvežavanje stranice neće prikazati promene koje su unete, onda se primenjuje kod ispod
'''if iface.mapCanvas().isCachingEnabled():
    layer.triggerRepaint()
else:
    iface.mapCanvas().refresh()'''
#pravi listu od ID-va
fidd = []
for feature in sloj.getFeatures():
    fidd.append(feature.id())
print(fidd)

feat1 = feat2 = QgsFeature(sloj.fields())
fid = 1 #
feat1.setId(fid)

# dodaje dva featurea (instance QgsFeature)
# sloj.addFeatures([feat1,feat2])

# brise feature sa prethodno definisanim FID-om
# sloj.deleteFeature(fid)









