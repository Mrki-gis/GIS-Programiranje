canvas = QgsMapCanvas()
canvas.show()
#odmah otvara belu pozdainu...možda je do verzije
canvas.setCanvasColor(Qt.white)
canvas.enableAntiAliasing(True)


vlayer = iface.activeLayer()

if not vlayer.isValid():
    print('Sloj nije uspešno učitan!')

#podešavanje obima sloja
canvas.setExtent(vlayer.extent())
#podešava slojeve za 'platno mape'
canvas.setLayers([vlayer])

