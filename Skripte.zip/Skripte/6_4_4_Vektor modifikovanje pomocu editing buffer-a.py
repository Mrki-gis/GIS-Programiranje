putanja_do_sloja2 = "C:/Users/Korisnik/Desktop/ProjekatM/QGIS_projekat/Nova_Varos_kandidat.shp"

olayer=QgsVectorLayer(putanja_do_sloja2,'Nova_Varos_kandidat','ogr')
if not olayer.isValid():
    print('Sloj ne može da se učita')
else:
    QgsProject.instance().addMapLayer(olayer)

olayer = iface.activeLayer()

# proverava da li je određena funkcija podržana
caps = olayer.dataProvider().capabilities()

if caps and QgsVectorDataProvider.AddAttributes:
    print('Sloj podržava dodavanje atributa!')

# Proverava sve funkcije sloja
caps_string = olayer.dataProvider().capabilitiesString()
print(caps_string)


# dodavanje featurea
if caps and QgsVectorDataProvider.AddFeatures:
    feat = QgsFeature(olayer.fields())
    feat.setAttribute(0, 6)
    feat.setAttribute(1, 'Primer')
    feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(435958,4791954)))
    (res, outFeats) = olayer.dataProvider().addFeatures([feat])

# brisanje featurea
#if caps and QgsVectorDataProvider.DeleteFeatures:
    #res = olayer.dataProvider().deleteFeatures([2,3])
# res

# Menjanje featurea (geometrije ili atributa)
# obratiti pažnju na to koji je FID od featurea
#fid = 3 - postoji mogucnost da je doslo do promene FIDa

#if caps and QgsVectorDataProvider.ChangeAttributeValues:
    #atributi = {0 : 6, 1: 'Primer'}
    #olayer.dataProvider().changeAttributeValues({fid : atributi})
